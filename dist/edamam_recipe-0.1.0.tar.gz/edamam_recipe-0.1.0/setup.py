# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['edamam_recipe']

package_data = \
{'': ['*']}

install_requires = \
['pandas>=1.1.5,<2.0.0']

setup_kwargs = {
    'name': 'edamam-recipe',
    'version': '0.1.0',
    'description': 'Recipes!',
    'long_description': None,
    'author': 'Rui Lu',
    'author_email': 'rl3191@columbia.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
